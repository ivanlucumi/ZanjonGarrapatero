
<section class="hero-carousel" aria-label="Presentación y proyección multimedia destacada">
    <div id="inicioCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="6500" data-bs-pause="hover" data-bs-wrap="true">
        
        <?php if(isset($carouselSlides) && $carouselSlides->isNotEmpty()): ?>
            <div class="carousel-indicators carousel-indicators-glass">
                <?php $__currentLoopData = $carouselSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-bs-target="#inicioCarousel" data-bs-slide-to="<?php echo e($idx); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>" aria-current="<?php echo e($loop->first ? 'true' : 'false'); ?>" aria-label="Proyección <?php echo e($loop->iteration); ?>: <?php echo e($slide->title); ?>"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="carousel-inner">
                <?php $__currentLoopData = $carouselSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($slide->isTextOnly()): ?>
                        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> slide-no-media">
                            <div class="wrap w-100 position-relative">
                                <div class="carousel-glass-panel">
                                    <span class="projection-badge mb-2">
                                        <span class="dot-live"></span> <?php echo e($slide->badge_text ?? 'Comunicado · Identidad & Organización'); ?>

                                    </span>
                                    <h2 class="serif"><?php echo e($slide->title); ?></h2>
                                    <?php if($slide->subtitle): ?><p><?php echo e($slide->subtitle); ?></p><?php endif; ?>
                                    <div class="d-flex gap-3 flex-wrap align-items-center">
                                        <?php if($slide->primary_button_text): ?>
                                            <a class="btn btn-main" href="<?php echo e($slide->primary_button_url ?: route('nosotros')); ?>">
                                                <?php echo e($slide->primary_button_text); ?> <i class="bi bi-arrow-right ms-2"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if($slide->secondary_button_text): ?>
                                            <a class="btn btn-ghost" href="<?php echo e($slide->secondary_button_url ?: route('actualidad')); ?>">
                                                <?php echo e($slide->secondary_button_text); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> has-media">
                            <div class="carousel-media-container">
                                <?php if($slide->isVideo()): ?>
                                    <video class="carousel-media" autoplay muted loop playsinline poster="<?php echo e($slide->poster_url); ?>">
                                        <source src="<?php echo e($slide->media_url); ?>" type="video/mp4">
                                    </video>
                                <?php else: ?>
                                    <img src="<?php echo e($slide->media_url); ?>" alt="<?php echo e($slide->title); ?>" class="carousel-media" loading="<?php echo e($loop->first ? 'eager' : 'lazy'); ?>">
                                <?php endif; ?>
                                <div class="carousel-overlay"></div>
                            </div>
                            <div class="wrap w-100 position-relative">
                                <div class="carousel-glass-panel">
                                    <span class="projection-badge mb-2">
                                        <span class="dot-live"></span> <?php echo e($slide->badge_text ?? ($slide->isVideo() ? 'Proyección · Video en Vivo' : 'Proyección · Imagen del Territorio')); ?>

                                    </span>
                                    <?php if($loop->first): ?>
                                        <h1 class="serif"><?php echo e($slide->title); ?></h1>
                                    <?php else: ?>
                                        <h2 class="serif"><?php echo e($slide->title); ?></h2>
                                    <?php endif; ?>
                                    <?php if($slide->subtitle): ?><p><?php echo e($slide->subtitle); ?></p><?php endif; ?>
                                    <div class="d-flex gap-3 flex-wrap align-items-center">
                                        <?php if($slide->primary_button_text): ?>
                                            <a class="btn btn-main" href="<?php echo e($slide->primary_button_url ?: route('nosotros')); ?>">
                                                <?php echo e($slide->primary_button_text); ?> <i class="bi bi-arrow-right ms-2"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if($slide->media_url): ?>
                                            <button type="button" class="btn-projection" data-media-type="<?php echo e($slide->isVideo() ? 'video' : 'image'); ?>" data-media-src="<?php echo e($slide->media_url); ?>" data-media-title="<?php echo e($slide->projection_title ?: $slide->title); ?>">
                                                <i class="bi <?php echo e($slide->isVideo() ? 'bi-play-circle-fill' : 'bi-fullscreen'); ?>" <?php if($slide->isVideo()): ?> style="color: var(--brand-accent);" <?php endif; ?>></i> <?php echo e($slide->isVideo() ? 'Proyectar Video' : 'Proyectar Imagen'); ?>

                                            </button>
                                        <?php endif; ?>
                                        <?php if($slide->secondary_button_text): ?>
                                            <a class="btn btn-ghost" href="<?php echo e($slide->secondary_button_url); ?>">
                                                <?php echo e($slide->secondary_button_text); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="carousel-indicators carousel-indicators-glass">
                <button type="button" data-bs-target="#inicioCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Proyección 1: Territorio (Imagen)"></button>
                <button type="button" data-bs-target="#inicioCarousel" data-bs-slide-to="1" aria-label="Proyección 2: Saberes (Video)"></button>
                <button type="button" data-bs-target="#inicioCarousel" data-bs-slide-to="2" aria-label="Comunicado 3: Editorial (Sin video)"></button>
                <button type="button" data-bs-target="#inicioCarousel" data-bs-slide-to="3" aria-label="Proyección 4: Guardia (Video)"></button>
            </div>

            <div class="carousel-inner">
                
                <div class="carousel-item active has-media">
                    <div class="carousel-media-container">
                        <img src="https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=1920&q=85" alt="Paisaje natural del Zanjón de Garrapatero" class="carousel-media" loading="eager">
                        <div class="carousel-overlay"></div>
                    </div>
                    <div class="wrap w-100 position-relative">
                        <div class="carousel-glass-panel">
                            <span class="projection-badge mb-2">
                                <span class="dot-live"></span> Proyección · Imagen del Territorio
                            </span>
                            <h1 class="serif">Territorio que se reconoce, comunidad que avanza.</h1>
                            <p>Una presencia digital soberana para conectar memoria, organización, cultura y participación comunitaria afrocolombiana.</p>
                            <div class="d-flex gap-3 flex-wrap align-items-center">
                                <a class="btn btn-main" href="<?php echo e(route('nosotros')); ?>">
                                    Conocer el Consejo <i class="bi bi-arrow-right ms-2"></i>
                                </a>
                                <button type="button" class="btn-projection" data-media-type="image" data-media-src="https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=1920&q=85" data-media-title="Paisaje y Cuencas Ancestrales — Zanjón de Garrapatero">
                                    <i class="bi bi-fullscreen"></i> Proyectar Imagen
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="carousel-item has-media">
                    <div class="carousel-media-container">
                        <video class="carousel-media" autoplay muted loop playsinline poster="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1920&q=85">
                            <source src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4" type="video/mp4">
                        </video>
                        <div class="carousel-overlay"></div>
                    </div>
                    <div class="wrap w-100 position-relative">
                        <div class="carousel-glass-panel">
                            <span class="projection-badge mb-2">
                                <span class="dot-live"></span> Proyección · Video en Vivo
                            </span>
                            <h2 class="serif">La voz de la comunidad también construye futuro.</h2>
                            <p>Noticias, asambleas veredales, proyectos productivos y canales para participar activamente en la vida del territorio.</p>
                            <div class="d-flex gap-3 flex-wrap align-items-center">
                                <a class="btn btn-main" href="<?php echo e(route('actividades')); ?>">
                                    Ver Actividades <i class="bi bi-arrow-right ms-2"></i>
                                </a>
                                <button type="button" class="btn-projection" data-media-type="video" data-media-src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4" data-media-title="Relatos y Saberes Comunitarios en Movimiento">
                                    <i class="bi bi-play-circle-fill" style="color: var(--brand-accent);"></i> Proyectar Video
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="carousel-item slide-no-media">
                    <div class="wrap w-100 position-relative">
                        <div class="carousel-glass-panel">
                            <span class="projection-badge mb-2">
                                <span class="dot-live"></span> Comunicado · Identidad &amp; Organización
                            </span>
                            <h2 class="serif">Historias, acuerdos y memoria que construyen autonomía.</h2>
                            <p>Una presencia institucional transparente para coordinar proyectos productivos, censo étnico y el cuidado colectivo de nuestra gente.</p>
                            <div class="d-flex gap-3 flex-wrap align-items-center">
                                <a class="btn btn-main" href="<?php echo e(route('nosotros')); ?>">
                                    Conocer el Consejo <i class="bi bi-arrow-right ms-2"></i>
                                </a>
                                <a class="btn btn-ghost" href="<?php echo e(route('actualidad')); ?>">
                                    Ver Comunicados <i class="bi bi-newspaper ms-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="carousel-item has-media">
                    <div class="carousel-media-container">
                        <video class="carousel-media" autoplay muted loop playsinline poster="https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1920&q=85">
                            <source src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" type="video/mp4">
                        </video>
                        <div class="carousel-overlay"></div>
                    </div>
                    <div class="wrap w-100 position-relative">
                        <div class="carousel-glass-panel">
                            <span class="projection-badge mb-2">
                                <span class="dot-live"></span> Proyección · Guardia y Cuencas
                            </span>
                            <h2 class="serif">Cuidado integral de nuestras aguas y linderos ancestrales.</h2>
                            <p>Recorridos de prevención pacífica, cuidado ambiental y autonomía colectiva en las 8 veredas articuladas.</p>
                            <div class="d-flex gap-3 flex-wrap align-items-center">
                                <a class="btn btn-main" href="<?php echo e(route('territorio')); ?>">
                                    Explorar Veredas <i class="bi bi-compass ms-2"></i>
                                </a>
                                <button type="button" class="btn-projection" data-media-type="video" data-media-src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" data-media-title="Custodia del Territorio y Fuentes Hídricas">
                                    <i class="bi bi-play-circle-fill" style="color: var(--brand-accent);"></i> Proyectar Video
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        
        <button class="carousel-control-glass prev" type="button" data-bs-target="#inicioCarousel" data-bs-slide="prev" aria-label="Diapositiva anterior">
            <i class="bi bi-chevron-left" aria-hidden="true"></i>
        </button>
        <button class="carousel-control-glass next" type="button" data-bs-target="#inicioCarousel" data-bs-slide="next" aria-label="Diapositiva siguiente">
            <i class="bi bi-chevron-right" aria-hidden="true"></i>
        </button>
    </div>
</section>


<div class="relief-divider" aria-hidden="true"></div>


<section class="hero">
    <div class="wrap hero-grid">
        <div>
            <div class="eyebrow">Cauca · Colombia · Comunidad afro</div>
            <h1>Un territorio que <em>se reconoce</em> y se proyecta.</h1>
            <p class="hero-lead">Una plataforma institucional para contar quiénes somos, cuidar la memoria colectiva y conectar las voces del Consejo Comunitario Zanjón de Garrapatero con su gente y con el mundo.</p>
            <div class="hero-actions">
                <a class="btn btn-main" href="<?php echo e(route('nosotros')); ?>">
                    Conocer el Consejo <i class="bi bi-arrow-right ms-1"></i>
                </a>
                <a class="btn btn-ghost" href="<?php echo e(route('actualidad')); ?>">
                    Ver actualidad <i class="bi bi-newspaper ms-1"></i>
                </a>
            </div>
            <div class="hero-note">
                <div>
                    <strong>3.131</strong>
                    registros de referencia
                </div>
                <div class="rule"></div>
                <div>
                    <strong>08</strong>
                    territorios identificados
                </div>
            </div>
        </div>
        <div class="orbital">
            <div class="orbit-card float">
                <span class="orbit-dot d1"></span>
                <span class="orbit-dot d2"></span>
                <span class="orbit-dot d3"></span>
                <div class="orbit-logo">
                    <img src="<?php echo e(asset('logo/logo.webp')); ?>" alt="Identidad visual del Consejo Comunitario Zanjón de Garrapatero" width="220" height="220">
                </div>
                <div class="triad-mark" aria-label="Triada cromática institucional #172D4D, #F4F1EA y #B58A45">
                    <span class="triad-primary" title="#172D4D Principal"></span>
                    <span class="triad-secondary" title="#F4F1EA Secundario"></span>
                    <span class="triad-accent" title="#B58A45 Secundario"></span>
                </div>
                <div class="triad-key">
                    <b class="primary"></b> <span class="triad-val-primary">#172D4D</span> <b class="secondary"></b> <span class="triad-val-secondary">#F4F1EA</span> <b class="accent"></b> <span class="triad-val-accent">#B58A45</span>
                </div>
                <div class="orbit-caption">
                    <b>CCZG</b> · símbolo vivo del territorio
                </div>
            </div>
        </div>
    </div>
</section>


<div class="relief-divider" aria-hidden="true"></div>


<section class="section section-light">
    <div class="wrap">
        <div class="d-flex justify-content-between align-items-end flex-wrap gap-3 mb-4">
            <div class="section-header mb-0">
                <div class="kicker">01 · Quiénes somos</div>
                <h2 class="section-title serif">Gobierno propio, memoria y futuro.</h2>
                <p class="section-copy">El Consejo Comunitario Zanjón de Garrapatero es una organización territorial afro que articula comunidad, cultura, participación y cuidado del territorio.</p>
            </div>
            <a href="<?php echo e(route('nosotros')); ?>" class="btn btn-main">
                Página Nosotros <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>
        <div class="row g-4 align-items-stretch">
            <div class="col-lg-7">
                <div class="p-4 p-lg-5 rounded-4 h-100" style="background: rgba(23, 45, 77, 0.05); border: 1px solid rgba(23, 45, 77, 0.1);">
                    <div class="kicker">Nuestra mirada</div>
                    <h3 class="serif display-6 mt-3">“La organización nace de la gente y vuelve a la gente.”</h3>
                    <p class="section-copy mt-3 mb-4">El Consejo Comunitario trabaja por el bienestar de las familias afrocolombianas, la protección de las cuencas hídricas y el ejercicio pacífico de la autonomía en el territorio.</p>
                    <a href="<?php echo e(route('nosotros')); ?>" class="read-more">Conocer visión, historia y gobernanza <i class="bi bi-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="glass-card p-4 p-lg-5 h-100" style="border: 1px solid rgba(181, 138, 69, 0.35);">
                    <div class="kicker">Identidad institucional</div>
                    <h3 class="mt-3" style="color: var(--brand-primary);">Símbolos y colores del Consejo</h3>
                    <p style="color: var(--text-muted); line-height: 1.7;">Cada tono representa los principios de la comunidad: soberanía territorial en azul #172D4D, dignidad y memoria en tono marfil #F4F1EA, y riqueza colectiva en oro ancestral #B58A45.</p>
                    <div class="stat-row">
                        <div class="stat">
                            <b style="color: var(--brand-primary);" class="triad-val-primary">#172D4D</b>
                            <span>Territorio</span>
                        </div>
                        <div class="stat">
                            <b style="color: var(--brand-accent);" class="triad-val-secondary">#F4F1EA</b>
                            <span>Dignidad</span>
                        </div>
                        <div class="stat">
                            <b style="color: var(--brand-accent);" class="triad-val-accent">#B58A45</b>
                            <span>Saber colectivo</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<div class="relief-divider" aria-hidden="true"></div>


<section class="section">
    <div class="wrap">
        <div class="d-flex justify-content-between align-items-end flex-wrap gap-3 mb-4">
            <div class="section-header mb-0">
                <div class="kicker">02 · Territorio</div>
                <h2 class="section-title serif">Un mapa de relaciones, no solo de lugares.</h2>
                <p class="section-copy">Veredas, reservas, centros comunitarios y espacios de encuentro que tejen la vida comunitaria.</p>
            </div>
            <a href="<?php echo e(route('territorio')); ?>" class="btn btn-ghost">
                Ver todos los territorios <i class="bi bi-map ms-1"></i>
            </a>
        </div>
        <div class="mini-grid">
            <?php if(isset($territories) && $territories->isNotEmpty()): ?>
                <?php $__currentLoopData = $territories->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="territory">
                        <?php if($t->sector_badge): ?>
                            <span class="badge rounded-pill mb-2 px-2 py-1" style="background: rgba(181, 138, 69, 0.3); color: #ffffff; border: 1px solid rgba(181, 138, 69, 0.5); font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase;">
                                <i class="bi bi-geo-alt-fill me-1"></i> <?php echo e($t->sector_badge); ?>

                            </span>
                        <?php endif; ?>
                        <h3><?php echo e($t->name); ?></h3>
                        <p><?php echo e(Str::limit($t->description, 85)); ?></p>
                        <a href="<?php echo e(route('territorio')); ?>" class="read-more text-white">Conocer más <i class="bi bi-arrow-right"></i></a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <article class="territory">
                    <span class="badge rounded-pill mb-2 px-2 py-1" style="background: rgba(181, 138, 69, 0.3); color: #ffffff; border: 1px solid rgba(181, 138, 69, 0.5); font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase;">
                        <i class="bi bi-geo-alt-fill me-1"></i> Sector Central
                    </span>
                    <h3>El Palmar</h3>
                    <p>La mayor concentración de registros en la base de referencia comunitaria.</p>
                    <a href="<?php echo e(route('territorio')); ?>" class="read-more text-white">Conocer más <i class="bi bi-arrow-right"></i></a>
                </article>
                <article class="territory">
                    <span class="badge rounded-pill mb-2 px-2 py-1" style="background: rgba(181, 138, 69, 0.3); color: #ffffff; border: 1px solid rgba(181, 138, 69, 0.5); font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase;">
                        <i class="bi bi-tree-fill me-1"></i> Cuenca Alta
                    </span>
                    <h3>Santa Lucía</h3>
                    <p>Comunidad, recorridos y memoria que conectan el paisaje ancestral.</p>
                    <a href="<?php echo e(route('territorio')); ?>" class="read-more text-white">Conocer más <i class="bi bi-arrow-right"></i></a>
                </article>
                <article class="territory">
                    <span class="badge rounded-pill mb-2 px-2 py-1" style="background: rgba(181, 138, 69, 0.3); color: #ffffff; border: 1px solid rgba(181, 138, 69, 0.5); font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase;">
                        <i class="bi bi-water me-1"></i> Reserva Hídrica
                    </span>
                    <h3>La Toma</h3>
                    <p>Territorio y organización como ejercicio permanente de autonomía.</p>
                    <a href="<?php echo e(route('territorio')); ?>" class="read-more text-white">Conocer más <i class="bi bi-arrow-right"></i></a>
                </article>
                <article class="territory">
                    <span class="badge rounded-pill mb-2 px-2 py-1" style="background: rgba(181, 138, 69, 0.3); color: #ffffff; border: 1px solid rgba(181, 138, 69, 0.5); font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase;">
                        <i class="bi bi-people-fill me-1"></i> Familias Campesinas
                    </span>
                    <h3>Mazamorrero</h3>
                    <p>Una entrada para reconocer a las familias campesinas y sus historias.</p>
                    <a href="<?php echo e(route('territorio')); ?>" class="read-more text-white">Conocer más <i class="bi bi-arrow-right"></i></a>
                </article>
            <?php endif; ?>
        </div>
    </div>
</section>


<div class="relief-divider" aria-hidden="true"></div>


<section class="section manifesto">
    <div class="wrap">
        <div class="d-flex justify-content-between align-items-end flex-wrap gap-3 mb-4">
            <div class="section-header mb-0">
                <div class="kicker">03 · Actividades</div>
                <h2 class="section-title serif">La organización se mueve en comunidad.</h2>
                <p class="section-copy">Acciones que sostienen el territorio y fortalecen la participación ciudadana.</p>
            </div>
            <a href="<?php echo e(route('actividades')); ?>" class="btn btn-main">
                Explorar actividades <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>
        <div class="row g-3">
            <div class="col-md-6 col-xl-3">
                <article class="activity-card">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-4 p-3 mb-3" style="width: 54px; height: 54px; background: rgba(181, 138, 69, 0.16); color: var(--brand-accent); border: 1px solid rgba(181, 138, 69, 0.35);">
                        <i class="bi bi-megaphone fs-4"></i>
                    </div>
                    <h3>Asambleas</h3>
                    <p>Convocatorias, acuerdos y próximos encuentros de la comunidad.</p>
                    <a href="<?php echo e(route('actividades')); ?>" class="read-more mt-auto pt-2">Ver agenda <i class="bi bi-arrow-right"></i></a>
                </article>
            </div>
            <div class="col-md-6 col-xl-3">
                <article class="activity-card">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-4 p-3 mb-3" style="width: 54px; height: 54px; background: rgba(23, 45, 77, 0.08); color: var(--brand-primary); border: 1px solid rgba(23, 45, 77, 0.18);">
                        <i class="bi bi-tree fs-4"></i>
                    </div>
                    <h3>Cuidado territorial</h3>
                    <p>Acciones de protección, recorridos, reservas y memoria ambiental.</p>
                    <a href="<?php echo e(route('actividades')); ?>" class="read-more mt-auto pt-2">Ver acciones <i class="bi bi-arrow-right"></i></a>
                </article>
            </div>
            <div class="col-md-6 col-xl-3">
                <article class="activity-card">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-4 p-3 mb-3" style="width: 54px; height: 54px; background: rgba(181, 138, 69, 0.16); color: var(--brand-accent); border: 1px solid rgba(181, 138, 69, 0.35);">
                        <i class="bi bi-music-note-beamed fs-4"></i>
                    </div>
                    <h3>Cultura viva</h3>
                    <p>Cimarrona, saberes ancestrales y relatos que conectan generaciones.</p>
                    <a href="<?php echo e(route('actividades')); ?>" class="read-more mt-auto pt-2">Ver saberes <i class="bi bi-arrow-right"></i></a>
                </article>
            </div>
            <div class="col-md-6 col-xl-3">
                <article class="activity-card">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-4 p-3 mb-3" style="width: 54px; height: 54px; background: rgba(23, 45, 77, 0.08); color: var(--brand-primary); border: 1px solid rgba(23, 45, 77, 0.18);">
                        <i class="bi bi-person-check fs-4"></i>
                    </div>
                    <h3>Gestión comunitaria</h3>
                    <p>Censo, avales, proyectos y canales de atención para las familias.</p>
                    <a href="<?php echo e(route('actividades')); ?>" class="read-more mt-auto pt-2">Ver trámites <i class="bi bi-arrow-right"></i></a>
                </article>
            </div>
        </div>
    </div>
</section>


<div class="relief-divider" aria-hidden="true"></div>


<section class="section section-light">
    <div class="wrap">
        <div class="d-flex justify-content-between align-items-end flex-wrap gap-3 mb-4">
            <div class="section-header mb-0">
                <div class="kicker">04 · Galería</div>
                <h2 class="section-title serif">Rostros, caminos y memoria.</h2>
                <p class="section-copy">Registro visual para documentar el territorio con fotografías reales de nuestra gente y sus paisajes.</p>
            </div>
            <a href="<?php echo e(route('galeria')); ?>" class="btn btn-main">
                Ver galería completa <i class="bi bi-images ms-1"></i>
            </a>
        </div>
        <div class="gallery-grid">
            <?php if(isset($featuredMedia) && $featuredMedia->isNotEmpty()): ?>
                <?php $__currentLoopData = $featuredMedia->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure class="gallery-item">
                        <img src="<?php echo e($fm->file_url); ?>" alt="<?php echo e($fm->title); ?>" loading="lazy">
                        <figcaption><?php echo e($fm->caption ?: $fm->title); ?></figcaption>
                    </figure>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <figure class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=1200&q=85" alt="Paisaje verde de territorio comunitario" loading="lazy">
                    <figcaption>Territorio que se cuida</figcaption>
                </figure>
                <figure class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=85" alt="Personas reunidas en comunidad" loading="lazy">
                    <figcaption>Encuentro y participación</figcaption>
                </figure>
                <figure class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=85" alt="Actividad cultural con público" loading="lazy">
                    <figcaption>Cultura viva</figcaption>
                </figure>
                <figure class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1474511320723-9a56873867b5?auto=format&fit=crop&w=800&q=85" alt="Camino entre árboles" loading="lazy">
                    <figcaption>Memoria del paisaje</figcaption>
                </figure>
                <figure class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=800&q=85" alt="Equipo dialogando alrededor de una mesa" loading="lazy">
                    <figcaption>Organización y futuro</figcaption>
                </figure>
            <?php endif; ?>
        </div>
    </div>
</section>


<div class="relief-divider" aria-hidden="true"></div>


<section class="section section-light">
    <div class="wrap">
        <div class="d-flex justify-content-between align-items-end flex-wrap gap-3 mb-4">
            <div class="section-header mb-0">
                <div class="kicker">05 · Actualidad</div>
                <h2 class="section-title serif">La comunidad también se cuenta en presente.</h2>
            </div>
            <a href="<?php echo e(route('actualidad')); ?>" class="btn btn-main">
                Ir a Actualidad <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>
        <div class="row g-4">
            <?php if(isset($publications) && $publications->isNotEmpty()): ?>
                <?php $__currentLoopData = $publications->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <article class="news-card">
                            <span class="news-date"><?php echo e($pub->category); ?> · <?php echo e($pub->published_at ? $pub->published_at->format('d/m/Y') : date('Y')); ?></span>
                            <h3><?php echo e($pub->title); ?></h3>
                            <p><?php echo e($pub->summary ?: Str::limit($pub->content, 110)); ?></p>
                            <a class="read-more" href="<?php echo e(route('actualidad')); ?>">Leer más <i class="bi bi-arrow-up-right"></i></a>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-md-4">
                    <article class="news-card">
                        <span class="news-date">Agenda · <?php echo e(date('F Y')); ?></span>
                        <h3>Presentación formal ante la asamblea</h3>
                        <p>Un encuentro para presentar la aplicación, sus objetivos y el camino de apropiación comunitaria.</p>
                        <a class="read-more" href="<?php echo e(route('actualidad')); ?>">Leer más <i class="bi bi-arrow-up-right"></i></a>
                    </article>
                </div>
                <div class="col-md-4">
                    <article class="news-card">
                        <span class="news-date">Proceso · Censo</span>
                        <h3>Hacia un registro comunitario ampliado</h3>
                        <p>La plataforma permitirá solicitar registro, adjuntar documento y validar pertenencia territorial.</p>
                        <a class="read-more" href="<?php echo e(route('actualidad')); ?>">Conocer proceso <i class="bi bi-arrow-up-right"></i></a>
                    </article>
                </div>
                <div class="col-md-4">
                    <article class="news-card">
                        <span class="news-date">Cultura · Memoria</span>
                        <h3>Noticias, eventos y comunicados</h3>
                        <p>Un archivo público y vivo para que la comunidad encuentre información verificada en un solo lugar.</p>
                        <a class="read-more" href="<?php echo e(route('actualidad')); ?>">Ver comunicados <i class="bi bi-arrow-up-right"></i></a>
                    </article>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>


<div class="relief-divider" aria-hidden="true"></div>


<section class="parallax-band" data-parallax="0.16">
    <div class="wrap">
        <div class="parallax-content">
            <div class="kicker">Territorio en movimiento</div>
            <h2 class="serif mt-3">Cada camino guarda una historia.</h2>
            <p class="mt-4">Participa activamente en las decisiones y en el crecimiento de nuestra comunidad afro.</p>
            <div class="d-flex gap-3 flex-wrap">
                <a class="btn btn-main" href="<?php echo e(route('contacto')); ?>">
                    Contáctanos <i class="bi bi-arrow-up-right ms-2"></i>
                </a>
                <a class="btn btn-ghost" href="<?php echo e(route('territorio')); ?>">
                    Explorar territorios <i class="bi bi-compass ms-2"></i>
                </a>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/layouts/index/content.blade.php ENDPATH**/ ?>