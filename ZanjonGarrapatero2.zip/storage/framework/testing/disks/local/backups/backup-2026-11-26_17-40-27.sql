-- Respaldo Completo de Base de Datos: :memory:
-- Fecha: 2026-11-26T17:40:27+00:00
-- Driver: sqlite

DROP TABLE IF EXISTS "migrations";
CREATE TABLE "migrations" ("id" integer primary key autoincrement not null, "migration" varchar not null, "batch" integer not null);

INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('1', '0001_01_01_000000_create_users_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('2', '0001_01_01_000001_create_cache_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('3', '0001_01_01_000002_create_jobs_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('4', '2026_11_16_230812_add_role_and_profile_to_users_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('5', '2026_11_16_231031_create_surveys_and_responses_tables', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('6', '2026_11_16_235524_create_publications_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('7', '2026_11_16_235525_create_activities_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('8', '2026_11_16_235526_create_media_items_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('9', '2026_11_16_235527_create_audit_logs_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('10', '2026_11_16_235528_create_login_logs_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('11', '2026_11_17_002550_create_carousel_slides_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('12', '2026_11_17_002556_create_contact_messages_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('13', '2026_11_17_002601_create_territories_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('14', '2026_11_17_002602_create_board_members_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('15', '2026_11_17_004736_create_documents_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('16', '2026_11_17_004741_add_attachments_to_publications_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('17', '2026_11_26_162939_add_active_dates_to_publications_and_activities_tables', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('18', '2026_11_26_162940_create_sent_emails_table', '1');
INSERT INTO "migrations" ("id", "migration", "batch") VALUES ('19', '2026_11_26_164340_add_attachments_and_retry_stats_to_sent_emails_table', '1');

DROP TABLE IF EXISTS "users";
CREATE TABLE "users" ("id" integer primary key autoincrement not null, "name" varchar not null, "email" varchar not null, "email_verified_at" datetime, "password" varchar not null, "remember_token" varchar, "created_at" datetime, "updated_at" datetime, "role" varchar not null default 'usuario', "document_number" varchar, "phone" varchar, "vereda" varchar);


DROP TABLE IF EXISTS "password_reset_tokens";
CREATE TABLE "password_reset_tokens" ("email" varchar not null, "token" varchar not null, "created_at" datetime, primary key ("email"));


DROP TABLE IF EXISTS "sessions";
CREATE TABLE "sessions" ("id" varchar not null, "user_id" integer, "ip_address" varchar, "user_agent" text, "payload" text not null, "last_activity" integer not null, primary key ("id"));


DROP TABLE IF EXISTS "cache";
CREATE TABLE "cache" ("key" varchar not null, "value" text not null, "expiration" integer not null, primary key ("key"));


DROP TABLE IF EXISTS "cache_locks";
CREATE TABLE "cache_locks" ("key" varchar not null, "owner" varchar not null, "expiration" integer not null, primary key ("key"));


DROP TABLE IF EXISTS "jobs";
CREATE TABLE "jobs" ("id" integer primary key autoincrement not null, "queue" varchar not null, "payload" text not null, "attempts" integer not null, "reserved_at" integer, "available_at" integer not null, "created_at" integer not null);


DROP TABLE IF EXISTS "job_batches";
CREATE TABLE "job_batches" ("id" varchar not null, "name" varchar not null, "total_jobs" integer not null, "pending_jobs" integer not null, "failed_jobs" integer not null, "failed_job_ids" text not null, "options" text, "cancelled_at" integer, "created_at" integer not null, "finished_at" integer, primary key ("id"));


DROP TABLE IF EXISTS "failed_jobs";
CREATE TABLE "failed_jobs" ("id" integer primary key autoincrement not null, "uuid" varchar not null, "connection" varchar not null, "queue" varchar not null, "payload" text not null, "exception" text not null, "failed_at" datetime not null default CURRENT_TIMESTAMP);


DROP TABLE IF EXISTS "surveys";
CREATE TABLE "surveys" ("id" integer primary key autoincrement not null, "title" varchar not null, "slug" varchar not null, "description" text, "category" varchar not null default 'Censo Territorial', "target_vereda" varchar, "status" varchar not null default 'active', "is_published" tinyint(1) not null default '1', "questions" text, "created_by" integer, "created_at" datetime, "updated_at" datetime, foreign key("created_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "survey_responses";
CREATE TABLE "survey_responses" ("id" integer primary key autoincrement not null, "survey_id" integer not null, "user_id" integer not null, "answers" text not null, "notes" text, "status" varchar not null default 'submitted', "created_at" datetime, "updated_at" datetime, foreign key("survey_id") references "surveys"("id") on delete cascade, foreign key("user_id") references "users"("id") on delete cascade);


DROP TABLE IF EXISTS "publications";
CREATE TABLE "publications" ("id" integer primary key autoincrement not null, "title" varchar not null, "slug" varchar not null, "category" varchar not null default 'Noticia', "summary" text, "content" text not null, "image_url" varchar, "author_id" integer, "is_visible" tinyint(1) not null default '1', "published_at" datetime, "created_at" datetime, "updated_at" datetime, "deleted_at" datetime, "attachment_url" varchar, "attachment_name" varchar, "attachment_size" integer, "active_from" datetime, "active_until" datetime, foreign key("author_id") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "activities";
CREATE TABLE "activities" ("id" integer primary key autoincrement not null, "title" varchar not null, "slug" varchar not null, "category" varchar not null default 'Asamblea', "description" text not null, "location" varchar, "event_date" datetime, "status" varchar not null default 'Convocatoria Abierta', "created_by" integer, "is_visible" tinyint(1) not null default '1', "created_at" datetime, "updated_at" datetime, "deleted_at" datetime, "active_from" datetime, "active_until" datetime, foreign key("created_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "media_items";
CREATE TABLE "media_items" ("id" integer primary key autoincrement not null, "title" varchar not null, "slug" varchar not null, "type" varchar not null default 'image', "category" varchar not null default 'Territorio', "caption" varchar, "file_url" varchar not null, "thumbnail_url" varchar, "duration" varchar, "is_featured" tinyint(1) not null default '0', "is_visible" tinyint(1) not null default '1', "created_by" integer, "created_at" datetime, "updated_at" datetime, "deleted_at" datetime, foreign key("created_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "audit_logs";
CREATE TABLE "audit_logs" ("id" integer primary key autoincrement not null, "user_id" integer, "user_name" varchar not null, "user_role" varchar not null, "action" varchar not null, "entity_type" varchar not null, "entity_id" integer, "entity_title" varchar, "description" varchar not null, "ip_address" varchar, "user_agent" text, "properties" text, "created_at" datetime not null default CURRENT_TIMESTAMP, foreign key("user_id") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "login_logs";
CREATE TABLE "login_logs" ("id" integer primary key autoincrement not null, "user_id" integer, "user_name" varchar not null, "user_email" varchar not null, "role" varchar not null, "ip_address" varchar, "user_agent" text, "login_at" datetime not null default CURRENT_TIMESTAMP, foreign key("user_id") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "carousel_slides";
CREATE TABLE "carousel_slides" ("id" integer primary key autoincrement not null, "title" varchar not null, "subtitle" text, "badge_text" varchar, "type" varchar not null default 'image', "media_url" text, "poster_url" text, "projection_title" varchar, "primary_button_text" varchar, "primary_button_url" varchar, "secondary_button_text" varchar, "secondary_button_url" varchar, "sort_order" integer not null default '0', "is_visible" tinyint(1) not null default '1', "created_by" integer, "deleted_at" datetime, "created_at" datetime, "updated_at" datetime, foreign key("created_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "contact_messages";
CREATE TABLE "contact_messages" ("id" integer primary key autoincrement not null, "name" varchar not null, "email" varchar not null, "phone" varchar, "territory" varchar not null, "message" text not null, "status" varchar not null default 'pendiente', "admin_notes" text, "attended_by" integer, "attended_at" datetime, "ip_address" varchar, "user_agent" text, "deleted_at" datetime, "created_at" datetime, "updated_at" datetime, foreign key("attended_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "territories";
CREATE TABLE "territories" ("id" integer primary key autoincrement not null, "name" varchar not null, "slug" varchar not null, "sector_badge" varchar, "description" text not null, "estimated_families" integer, "watersheds" varchar, "main_activities" varchar, "image_url" text, "sort_order" integer not null default '0', "is_visible" tinyint(1) not null default '1', "created_by" integer, "deleted_at" datetime, "created_at" datetime, "updated_at" datetime, foreign key("created_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "board_members";
CREATE TABLE "board_members" ("id" integer primary key autoincrement not null, "name" varchar not null, "role_title" varchar not null, "committee" varchar not null default 'Junta de Gobierno', "vereda" varchar, "bio" text, "phone" varchar, "email" varchar, "photo_url" text, "sort_order" integer not null default '0', "is_visible" tinyint(1) not null default '1', "created_by" integer, "deleted_at" datetime, "created_at" datetime, "updated_at" datetime, foreign key("created_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "documents";
CREATE TABLE "documents" ("id" integer primary key autoincrement not null, "title" varchar not null, "slug" varchar not null, "category" varchar not null default 'Normatividad', "description" text, "file_path" varchar not null, "file_name" varchar not null, "file_size" integer not null default '0', "mime_type" varchar not null default 'application/pdf', "download_count" integer not null default '0', "is_visible" tinyint(1) not null default '1', "created_by" integer, "deleted_at" datetime, "created_at" datetime, "updated_at" datetime, foreign key("created_by") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "sent_emails";
CREATE TABLE "sent_emails" ("id" integer primary key autoincrement not null, "sender_id" integer, "send_type" varchar not null default 'individual', "target_role" varchar, "recipient_user_id" integer, "subject" varchar not null, "body" text not null, "recipients_count" integer not null default '0', "recipient_emails" text, "sent_at" datetime, "created_at" datetime, "updated_at" datetime, "deleted_at" datetime, "attachments_meta" text, "failed_count" integer not null default '0', "failed_recipients" text, foreign key("sender_id") references "users"("id") on delete set null, foreign key("recipient_user_id") references "users"("id") on delete set null);


