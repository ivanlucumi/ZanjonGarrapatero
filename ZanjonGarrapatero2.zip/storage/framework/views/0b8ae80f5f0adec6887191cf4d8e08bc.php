<?php $__env->startSection('title', 'Encuestas y Censos Comunitarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
    <div>
        <h2 class="h3 fw-bold text-dark mb-1">Encuestas y Censos Territoriales</h2>
        <p class="text-muted small mb-0">
            Instrumentos de consulta y recolección de información comunitaria para la toma de decisiones autónomas.
        </p>
    </div>

    <?php if(Auth::user()->role->canManageSurveys()): ?>
        <div>
            <a href="<?php echo e(route('admin.surveys.create')); ?>" class="btn-admin-gold">
                <i class="bi bi-plus-circle-fill"></i> Crear Nueva Encuesta
            </a>
        </div>
    <?php endif; ?>
</div>

<!-- SEPARADOR -->
<div class="relief-divider">
    <div class="relief-divider-dot"></div>
</div>

<?php if(Auth::user()->isUsuario()): ?>
    
    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $hasAnswered = in_array($survey->id, $myResponseSurveyIds, true);
            ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="admin-card h-100 d-flex flex-column justify-content-between">
                    <div>
                        <div class="admin-card-header">
                            <span class="badge bg-light text-primary border"><?php echo e($survey->category); ?></span>
                            <?php if($hasAnswered): ?>
                                <span class="badge bg-success-subtle text-success border border-success-subtle">
                                    <i class="bi bi-check-all"></i> Diligenciada
                                </span>
                            <?php elseif($survey->isActive()): ?>
                                <span class="badge bg-warning-subtle text-warning-emphasis border">
                                    <i class="bi bi-hourglass-split"></i> Pendiente
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Cerrada</span>
                            <?php endif; ?>
                        </div>
                        <div class="admin-card-body">
                            <h4 class="h5 fw-bold text-dark mb-2"><?php echo e($survey->title); ?></h4>
                            <p class="text-muted small mb-3"><?php echo e(Str::limit($survey->description, 130)); ?></p>
                            
                            <div class="small text-secondary mb-2">
                                <i class="bi bi-geo-alt-fill text-warning me-1"></i>
                                Vereda: <strong><?php echo e($survey->target_vereda ?? 'Todo el Territorio'); ?></strong>
                            </div>
                            <div class="small text-secondary">
                                <i class="bi bi-question-circle-fill text-primary me-1"></i>
                                Preguntas formuladas: <strong><?php echo e(is_array($survey->questions) ? count($survey->questions) : 0); ?></strong>
                            </div>
                        </div>
                    </div>
                    <div class="p-3 border-top bg-light-subtle text-end">
                        <?php if($hasAnswered): ?>
                            <button class="btn btn-sm btn-outline-success rounded-pill px-3" disabled>
                                <i class="bi bi-check-circle-fill me-1"></i> Respuesta Registrada
                            </button>
                        <?php elseif($survey->isActive()): ?>
                            <a href="<?php echo e(route('admin.surveys.respond', $survey)); ?>" class="btn-admin-gold py-1 px-3 small">
                                <i class="bi bi-pencil-fill me-1"></i> Diligenciar Censo
                            </a>
                        <?php else: ?>
                            <button class="btn btn-sm btn-secondary rounded-pill px-3" disabled>
                                Convocatoria Cerrada
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="admin-card p-5 text-center text-muted">
                    <i class="bi bi-inbox fs-1 d-block mb-3 text-secondary"></i>
                    No hay encuestas asignadas o activas para tu territorio en este momento.
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php else: ?>
    
    <div class="admin-card">
        <div class="admin-card-header">
            <h3 class="admin-card-title">
                <i class="bi bi-clipboard2-data-fill text-warning"></i>
                Listado Consolidado de Encuestas Comunitarias
            </h3>
        </div>
        <div class="admin-card-body p-0">
            <?php if($surveys->isEmpty()): ?>
                <div class="p-5 text-center text-muted">
                    <i class="bi bi-clipboard-x fs-1 d-block mb-3 text-secondary"></i>
                    Aún no se han configurado encuestas. Haz clic en "Crear Nueva Encuesta" para comenzar.
                </div>
            <?php else: ?>
                <div class="table-responsive px-3 py-2">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Encuesta</th>
                                <th>Categoría</th>
                                <th>Alcance Territorial</th>
                                <th>Respuestas</th>
                                <th>Estado</th>
                                <th>Creador</th>
                                <th class="text-end">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold text-dark"><?php echo e($survey->title); ?></div>
                                        <div class="small text-muted"><?php echo e(Str::limit($survey->description, 60)); ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-primary border"><?php echo e($survey->category); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?php echo e($survey->target_vereda ?? 'General (Todas)'); ?></span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.surveys.responses', $survey)); ?>" class="fw-bold text-primary text-decoration-none">
                                            <i class="bi bi-chat-left-dots-fill me-1"></i> <?php echo e($survey->responses_count); ?> respuestas
                                        </a>
                                    </td>
                                    <td>
                                        <?php if($survey->status === 'active'): ?>
                                            <span class="badge bg-success">Activa</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Cerrada</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="small text-secondary"><?php echo e($survey->creator->name ?? 'Sistema'); ?></span>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?php echo e(route('admin.surveys.show', $survey)); ?>" class="btn btn-outline-secondary" title="Detalle">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.surveys.responses', $survey)); ?>" class="btn btn-outline-primary" title="Respuestas">
                                                <i class="bi bi-bar-chart-fill"></i>
                                            </a>
                                            <form action="<?php echo e(route('admin.surveys.toggle-status', $survey)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn <?php echo e($survey->status === 'active' ? 'btn-outline-danger' : 'btn-outline-success'); ?>" title="<?php echo e($survey->status === 'active' ? 'Cerrar Encuesta' : 'Reabrir Encuesta'); ?>">
                                                    <?php echo e($survey->status === 'active' ? 'Cerrar' : 'Activar'); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="p-3 border-top">
                    <?php echo e($surveys->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/surveys/index.blade.php ENDPATH**/ ?>