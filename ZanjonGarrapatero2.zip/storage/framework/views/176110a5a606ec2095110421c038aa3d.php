======================================================================
ALERTA DE ERROR DEL SISTEMA - CONSEJO COMUNITARIO ZANJÓN DE GARRAPATERO
======================================================================

CÓDIGO DE ERROR: [<?php echo e($errorData['errorCode']); ?>]
TIPO DE EXCEPCIÓN: <?php echo e($errorData['exceptionClass']); ?>

MENSAJE: <?php echo e($errorData['errorMessage'] ?: 'Sin mensaje'); ?>


----------------------------------------------------------------------
DATOS DEL CONTEXTO DE EJECUCIÓN:
----------------------------------------------------------------------
- URL / Solicitud: [<?php echo e($errorData['method']); ?>] <?php echo e($errorData['url']); ?>

- Archivo y Línea: <?php echo e($errorData['file']); ?>:<?php echo e($errorData['line']); ?>

- Dirección IP: <?php echo e($errorData['ip']); ?>

- Usuario: <?php echo e($errorData['user'] ?? 'No autenticado / Invitado'); ?>

- Entorno: <?php echo e($errorData['environment']); ?>

- Fecha y Hora: <?php echo e($errorData['timestamp']); ?>


----------------------------------------------------------------------
TRAZA DE EJECUCIÓN (STACK TRACE):
----------------------------------------------------------------------
<?php echo e($errorData['trace']); ?>


======================================================================
Este reporte fue generado de manera automática por el sistema.
Los detalles han sido registrados en storage/logs/laravel.log.
======================================================================
<?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/emails/system-error-text.blade.php ENDPATH**/ ?>