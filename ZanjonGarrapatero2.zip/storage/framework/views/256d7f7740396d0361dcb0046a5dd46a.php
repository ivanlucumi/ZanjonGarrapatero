<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'cancelUrl',
    'submitText' => 'Guardar Cambios',
    'cancelText' => 'Cancelar',
    'icon' => 'bi-check-circle',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'cancelUrl',
    'submitText' => 'Guardar Cambios',
    'cancelText' => 'Cancelar',
    'icon' => 'bi-check-circle',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="admin-form-actions">
    <a href="<?php echo e($cancelUrl); ?>" class="admin-btn-cancel">
        <?php echo e($cancelText); ?>

    </a>
    <button type="submit" class="admin-btn-save">
        <i class="bi <?php echo e($icon); ?> me-1"></i> <?php echo e($submitText); ?>

    </button>
</div>
<?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/components/admin/actions.blade.php ENDPATH**/ ?>