<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'icon' => 'bi-pencil-square',
    'kicker' => null,
    'description' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'icon' => 'bi-pencil-square',
    'kicker' => null,
    'description' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'admin-form-card'])); ?>>
    <div class="admin-form-card-header">
        <div class="admin-form-icon-pill">
            <i class="bi <?php echo e($icon); ?>"></i>
        </div>
        <div>
            <?php if($kicker): ?>
                <span class="admin-form-card-kicker"><?php echo e($kicker); ?></span>
            <?php endif; ?>
            <h3 class="admin-form-card-title"><?php echo e($title); ?></h3>
            <?php if($description): ?>
                <p class="text-muted small mb-0"><?php echo e($description); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <div class="admin-form-card-body">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/components/admin/form-card.blade.php ENDPATH**/ ?>