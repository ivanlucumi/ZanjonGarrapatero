<?php $__env->startSection('title', 'Buzón de Mensajes y Contacto Territorial'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
    <div>
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle" style="font-size: 0.72rem; padding: 3px 10px;">
                <i class="bi bi-inbox-fill"></i> Atención a la Comunidad
            </span>
            <span class="text-muted small">&bull; Mensajes del Formulario de Contacto y Solicitudes</span>
        </div>
        <h2 class="h3 fw-bold text-dark mb-1">Buzón de Mensajes & Trámites Ciudadanos</h2>
        <p class="text-muted small mb-0">
            Revisa, atiende y responde las inquietudes, solicitudes de censo y trámites de avales radicados a través del portal.
        </p>
    </div>
    <?php if($unreadCount > 0): ?>
        <div>
            <span class="badge bg-warning-subtle text-warning-emphasis border border-warning px-3 py-2 fs-6 rounded-pill">
                <i class="bi bi-bell-fill me-1"></i> <?php echo e($unreadCount); ?> mensajes pendientes de atención
            </span>
        </div>
    <?php endif; ?>
</div>

<!-- FILTROS Y BÚSQUEDA -->
<div class="admin-card mb-4">
    <div class="admin-card-body py-3">
        <form method="GET" action="<?php echo e(route('admin.messages.index')); ?>" class="row g-2 align-items-center">
            <div class="col-12 col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Buscar por nombre, correo, vereda o contenido..." value="<?php echo e($search); ?>">
                </div>
            </div>
            <div class="col-6 col-md-3">
                <select name="status" class="form-select">
                    <option value="all" <?php echo e($status === 'all' ? 'selected' : ''); ?>>Todos los estados</option>
                    <option value="pendiente" <?php echo e($status === 'pendiente' ? 'selected' : ''); ?>>Pendientes de revisar</option>
                    <option value="en_tramite" <?php echo e($status === 'en_tramite' ? 'selected' : ''); ?>>En trámite</option>
                    <option value="atendido" <?php echo e($status === 'atendido' ? 'selected' : ''); ?>>Atendidos / Resueltos</option>
                    <option value="archivado" <?php echo e($status === 'archivado' ? 'selected' : ''); ?>>Archivados</option>
                    <option value="trashed" <?php echo e($status === 'trashed' ? 'selected' : ''); ?>>Papelera (SoftDelete)</option>
                </select>
            </div>
            <div class="col-6 col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-admin-primary flex-grow-1">Filtrar</button>
                <?php if($search || $status !== 'all'): ?>
                    <a href="<?php echo e(route('admin.messages.index')); ?>" class="btn btn-outline-secondary">Limpiar</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- TABLA DE MENSAJES -->
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h3 class="admin-card-title mb-0">
            <i class="bi bi-envelope-paper-fill text-primary"></i>
            Mensajes Recibidos (<?php echo e($messages->total()); ?>)
        </h3>
        <span class="text-muted small">
            <i class="bi bi-shield-check text-success me-1"></i>Trazabilidad de respuestas y archivo SoftDelete
        </span>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive px-3 py-2">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="min-width: 180px;">Remitente & Contacto</th>
                        <th>Vereda / Territorio</th>
                        <th style="min-width: 250px;">Mensaje / Solicitud</th>
                        <th>Estado</th>
                        <th>Fecha de Envío</th>
                        <th class="text-end" style="min-width: 150px;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($msg->trashed() ? 'bg-light opacity-75' : ($msg->status === 'pendiente' ? 'table-warning-subtle' : '')); ?>">
                            <td>
                                <div class="fw-bold text-dark"><?php echo e($msg->name); ?></div>
                                <div class="small text-muted"><?php echo e($msg->email); ?></div>
                                <?php if($msg->phone): ?>
                                    <div class="small text-secondary"><i class="bi bi-telephone me-1"></i><?php echo e($msg->phone); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border">
                                    <i class="bi bi-geo-alt-fill text-danger me-1"></i><?php echo e($msg->territory); ?>

                                </span>
                            </td>
                            <td>
                                <div class="small text-dark text-truncate" style="max-width: 320px;" title="<?php echo e($msg->message); ?>">
                                    <?php echo e($msg->message); ?>

                                </div>
                                <?php if($msg->admin_notes): ?>
                                    <div class="small text-success mt-1">
                                        <i class="bi bi-chat-left-text me-1"></i>Nota interna: <?php echo e(Str::limit($msg->admin_notes, 60)); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $st = $msg->statusBadge();
                                ?>
                                <?php if($msg->trashed()): ?>
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle" style="font-size: 0.75rem;">
                                        <i class="bi bi-archive-fill me-1"></i>En Papelera
                                    </span>
                                <?php else: ?>
                                    <span class="badge border <?php echo e($st['class']); ?>" style="font-size: 0.72rem;">
                                        <?php echo e($st['label']); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="small text-dark"><?php echo e($msg->created_at->format('d/m/Y')); ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;"><?php echo e($msg->created_at->diffForHumans()); ?></div>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-1 align-items-center">
                                    <!-- Ver / Atender -->
                                    <a href="<?php echo e(route('admin.messages.show', $msg->id)); ?>" class="btn btn-sm btn-outline-primary" title="Ver detalle y responder">
                                        <i class="bi bi-eye"></i> Atender
                                    </a>

                                    <?php if(!$msg->trashed()): ?>
                                        <!-- Inactivar / Archivar -->
                                        <form action="<?php echo e(route('admin.messages.destroy', $msg)); ?>" method="POST" class="d-inline js-confirm-delete" data-confirm-title="¿Archivar mensaje?" data-confirm-text="El mensaje de '<?php echo e($msg->name); ?>' pasará al archivo histórico mediante SoftDelete.">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Archivar mensaje">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <!-- Restaurar -->
                                        <form action="<?php echo e(route('admin.messages.restore', $msg->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-sm btn-success" title="Restaurar al buzón">
                                                <i class="bi bi-arrow-counterclockwise"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                No se encontraron mensajes en el buzón con los filtros aplicados.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($messages->hasPages()): ?>
            <div class="px-3 py-3 border-top">
                <?php echo e($messages->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>