<?php $__env->startSection('title', 'Detalle de Correo Enviado'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0" style="max-width: 880px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <span class="text-uppercase fw-bold small" style="color: #8d6e63; letter-spacing: 0.1em;">Registro de Envío #<?php echo e($sentEmail->id); ?></span>
            <h2 class="h3 fw-bold mb-0" style="color: #3e2723;"><?php echo e($sentEmail->subject); ?></h2>
        </div>
        <a href="<?php echo e(route('admin.emails.index')); ?>" class="btn btn-admin-outline">
            <i class="bi bi-arrow-left me-1"></i> Volver
        </a>
    </div>

    <div class="admin-card p-4 mb-4">
        <div class="row g-3 mb-4 pb-3 border-bottom">
            <div class="col-md-3">
                <span class="small text-muted d-block">Tipo de Envío</span>
                <strong class="text-dark"><?php echo e($sentEmail->typeLabel()); ?></strong>
            </div>
            <div class="col-md-3">
                <span class="small text-muted d-block">Remitente</span>
                <strong class="text-dark"><?php echo e($sentEmail->sender?->name ?? 'Sistema'); ?></strong>
            </div>
            <div class="col-md-3">
                <span class="small text-muted d-block">Fecha de Envío</span>
                <strong class="text-dark"><?php echo e($sentEmail->sent_at?->format('d/m/Y H:i') ?? $sentEmail->created_at->format('d/m/Y H:i')); ?></strong>
            </div>
            <div class="col-md-3">
                <span class="small text-muted d-block">Estado de Entrega</span>
                <strong class="text-success"><?php echo e($sentEmail->recipients_count); ?> enviados</strong>
                <?php if($sentEmail->failed_count > 0): ?>
                    <span class="text-danger small d-block"><?php echo e($sentEmail->failed_count); ?> fallaron tras reintentos</span>
                <?php endif; ?>
            </div>
        </div>

        <h6 class="fw-bold small text-uppercase text-muted mb-2">Cuerpo del Mensaje</h6>
        <div class="p-3 rounded-3 border bg-light mb-4" style="white-space: pre-line; line-height: 1.7;"><?php echo e($sentEmail->body); ?></div>

        <?php if(! empty($sentEmail->attachments_meta)): ?>
            <h6 class="fw-bold small text-uppercase text-muted mb-2">Archivos Adjuntos / Enlaces (<?php echo e(count($sentEmail->attachments_meta)); ?>)</h6>
            <div class="d-flex flex-wrap gap-2 mb-4">
                <?php $__currentLoopData = $sentEmail->attachments_meta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($att['url']); ?>" target="_blank" class="btn btn-sm btn-admin-outline">
                        <i class="bi <?php echo e(($att['delivery_mode'] ?? '') === 'link' ? 'bi-link-45deg' : 'bi-paperclip'); ?> me-1"></i>
                        <?php echo e($att['name']); ?> (<?php echo e($att['size_label']); ?>)
                        <span class="badge bg-light text-dark border ms-1"><?php echo e(($att['delivery_mode'] ?? '') === 'link' ? 'Enlace descarga' : 'Adjunto directo'); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <h6 class="fw-bold small text-uppercase text-muted mb-2">Destinatarios (<?php echo e($sentEmail->recipients_count); ?>)</h6>
        <div class="d-flex flex-wrap gap-2">
            <?php $__currentLoopData = $sentEmail->recipient_emails ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emailAddress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge bg-white text-dark border px-3 py-2"><?php echo e($emailAddress); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/emails/show.blade.php ENDPATH**/ ?>