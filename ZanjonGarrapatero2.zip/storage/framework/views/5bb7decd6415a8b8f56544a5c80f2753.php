<?php $__env->startSection('title', 'Editar Documento Institucional'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-form-container">
    <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
        <div>
            <a href="<?php echo e(route('admin.documents.index')); ?>" class="btn btn-sm btn-outline-secondary mb-2">
                <i class="bi bi-arrow-left me-1"></i> Volver al Repositorio
            </a>
            <h2 class="h3 fw-bold text-dark mb-1">Editar: <?php echo e($document->title); ?></h2>
            <p class="text-muted small mb-0">Toda modificación quedará registrada con fecha, usuario e IP en la bitácora de auditoría.</p>
        </div>
        <?php if($document->trashed()): ?>
            <span class="badge bg-danger-subtle text-danger border border-danger px-3 py-2 rounded-pill">
                <i class="bi bi-archive-fill me-1"></i> En papelera / Histórico (Inactivo)
            </span>
        <?php endif; ?>
    </div>

    <form method="POST" action="<?php echo e(route('admin.documents.update', $document->id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Clasificación Institucional','icon' => 'bi-file-earmark-text','kicker' => '01 · Metadatos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Clasificación Institucional','icon' => 'bi-file-earmark-text','kicker' => '01 · Metadatos']); ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'title','label' => 'Título del Documento','icon' => 'bi-type','value' => $document->title,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Título del Documento','icon' => 'bi-type','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($document->title),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-4">
                    <?php if (isset($component)) { $__componentOriginalcaa826401539fc57a784dadbb5b3020d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcaa826401539fc57a784dadbb5b3020d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.select','data' => ['name' => 'category','label' => 'Categoría Institucional','icon' => 'bi-folder2-open','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'category','label' => 'Categoría Institucional','icon' => 'bi-folder2-open','required' => true]); ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat); ?>" <?php echo e(old('category', $document->category) === $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $attributes = $__attributesOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $component = $__componentOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__componentOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
                </div>
                <div class="col-12">
                    <?php if (isset($component)) { $__componentOriginal694712473b787cd740db4e46be9da3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal694712473b787cd740db4e46be9da3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.textarea','data' => ['name' => 'description','label' => 'Descripción o Síntesis Informativa','rows' => '3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description','label' => 'Descripción o Síntesis Informativa','rows' => '3']); ?><?php echo e(old('description', $document->description)); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal694712473b787cd740db4e46be9da3f9)): ?>
<?php $attributes = $__attributesOriginal694712473b787cd740db4e46be9da3f9; ?>
<?php unset($__attributesOriginal694712473b787cd740db4e46be9da3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal694712473b787cd740db4e46be9da3f9)): ?>
<?php $component = $__componentOriginal694712473b787cd740db4e46be9da3f9; ?>
<?php unset($__componentOriginal694712473b787cd740db4e46be9da3f9); ?>
<?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Archivo y Reglas de Publicación','icon' => 'bi-cloud-arrow-up','kicker' => '02 · Adjunto & Visibilidad']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Archivo y Reglas de Publicación','icon' => 'bi-cloud-arrow-up','kicker' => '02 · Adjunto & Visibilidad']); ?>
            <div class="row g-3">
                
                <div class="col-12">
                    <div class="p-3 rounded-3 border bg-white d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <div class="d-flex align-items-center gap-3">
                            <div class="admin-form-icon-pill" style="margin: 0;">
                                <i class="bi <?php echo e($document->fileIcon()); ?> fs-4 text-primary"></i>
                            </div>
                            <div>
                                <div class="fw-bold text-dark"><?php echo e($document->file_name); ?></div>
                                <div class="text-muted small">
                                    <?php echo e($document->formattedSize()); ?> &bull; <?php echo e($document->download_count); ?> descargas registradas
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('admin.documents.download', $document->id)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-download me-1"></i> Descargar Copia
                        </a>
                    </div>
                </div>

                <div class="col-12 mt-2">
                    <?php if (isset($component)) { $__componentOriginalf579f53fd7bfeb562be03b4886ced604 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf579f53fd7bfeb562be03b4886ced604 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dropzone','data' => ['name' => 'document_file','label' => 'Reemplazar Archivo (Opcional)','accept' => '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.rar,.txt','badge' => 'Conservará el actual si no seleccionas uno nuevo • Máx 20 MB']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'document_file','label' => 'Reemplazar Archivo (Opcional)','accept' => '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.rar,.txt','badge' => 'Conservará el actual si no seleccionas uno nuevo • Máx 20 MB']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $attributes = $__attributesOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $component = $__componentOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__componentOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
                </div>

                <div class="col-12 mt-2">
                    <?php if (isset($component)) { $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.switch','data' => ['name' => 'is_visible','label' => 'Mantener Visible en la Biblioteca Comunitaria','description' => 'Permite que cualquier comunero o visitante consulte y descargue el documento desde el portal.','checked' => $document->is_visible]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'is_visible','label' => 'Mantener Visible en la Biblioteca Comunitaria','description' => 'Permite que cualquier comunero o visitante consulte y descargue el documento desde el portal.','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($document->is_visible)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $attributes = $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $component = $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala727e02234b4d11a6ac0075a108bae60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala727e02234b4d11a6ac0075a108bae60 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.actions','data' => ['cancelUrl' => ''.e(route('admin.documents.index')).'','submitText' => 'Guardar Cambios','icon' => 'bi-check-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['cancelUrl' => ''.e(route('admin.documents.index')).'','submitText' => 'Guardar Cambios','icon' => 'bi-check-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala727e02234b4d11a6ac0075a108bae60)): ?>
<?php $attributes = $__attributesOriginala727e02234b4d11a6ac0075a108bae60; ?>
<?php unset($__attributesOriginala727e02234b4d11a6ac0075a108bae60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala727e02234b4d11a6ac0075a108bae60)): ?>
<?php $component = $__componentOriginala727e02234b4d11a6ac0075a108bae60; ?>
<?php unset($__componentOriginala727e02234b4d11a6ac0075a108bae60); ?>
<?php endif; ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/documents/edit.blade.php ENDPATH**/ ?>