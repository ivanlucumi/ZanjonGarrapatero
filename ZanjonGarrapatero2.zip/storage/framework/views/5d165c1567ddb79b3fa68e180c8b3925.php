<?php $__env->startSection('title', 'Consejo Comunitario Zanjón de Garrapatero — Identidad, Territorio y Comunidad Afro'); ?>
<?php $__env->startSection('meta_description', 'Plataforma oficial del Consejo Comunitario Zanjón de Garrapatero — identidad, territorio, cultura y autonomía comunitaria afro.'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.index.content', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/layouts/index/index.blade.php ENDPATH**/ ?>