<?php $__env->startSection('content'); ?>
<div class="wrap">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="glass-card p-4 p-md-5">
                <div class="text-center mb-4">
                    <img src="<?php echo e(asset('logo/logo.webp')); ?>" alt="Logo Consejo Comunitario Zanjón de Garrapatero" width="56" height="56" class="brand-mark mb-2">
                    <h1 class="serif h3 mb-1" style="color: var(--brand-primary);">Registro Institucional</h1>
                    <p class="small" style="color: var(--text-muted);">
                        Crea una cuenta para vincularte a los procesos y consultas comunitarias
                    </p>
                </div>

                <form method="POST" action="<?php echo e(route('register')); ?>" novalidate>
                    <?php echo csrf_field(); ?>

                    <div class="form-glass-group mb-3">
                        <label for="name" class="form-glass-label"><?php echo e(__('Nombre Completo')); ?> <span class="text-danger">*</span></label>
                        <input id="name" type="text" class="form-glass-input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="Nombres y apellidos">

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-glass-feedback">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-glass-group mb-3">
                        <label for="email" class="form-glass-label"><?php echo e(__('Correo Electrónico')); ?> <span class="text-danger">*</span></label>
                        <input id="email" type="email" class="form-glass-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="ejemplo@correo.com">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-glass-feedback">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-glass-group mb-3">
                        <label for="password" class="form-glass-label"><?php echo e(__('Contraseña')); ?> <span class="text-danger">*</span></label>
                        <input id="password" type="password" class="form-glass-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password" placeholder="Mínimo 8 caracteres">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-glass-feedback">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-glass-group mb-4">
                        <label for="password-confirm" class="form-glass-label"><?php echo e(__('Confirmar Contraseña')); ?> <span class="text-danger">*</span></label>
                        <input id="password-confirm" type="password" class="form-glass-input" name="password_confirmation" required autocomplete="new-password" placeholder="Repite la contraseña">
                    </div>

                    <button type="submit" class="btn btn-main w-100 justify-content-center py-3 fs-6">
                        <i class="bi bi-person-check me-2"></i> <?php echo e(__('Completar Registro')); ?>

                    </button>
                </form>

                <div class="text-center mt-4 pt-3 border-top small" style="border-color: var(--line) !important; color: var(--text-muted);">
                    ¿Ya tienes una cuenta registrada?
                    <a href="<?php echo e(route('login')); ?>" class="btn-link ms-1 fw-bold">Iniciar sesión</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/auth/register.blade.php ENDPATH**/ ?>