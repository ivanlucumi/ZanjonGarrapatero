<?php $__env->startSection('title', 'Diligenciar Encuesta — ' . $survey->title); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-xl-8">
        <div class="mb-4">
            <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-sm btn-admin-outline mb-2">
                <i class="bi bi-arrow-left"></i> Volver al Listado
            </a>
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="badge bg-light text-primary border"><?php echo e($survey->category); ?></span>
                <span class="badge bg-light text-dark border"><i class="bi bi-geo-alt"></i> <?php echo e($survey->target_vereda ?? 'Territorio Completo'); ?></span>
            </div>
            <h2 class="h3 fw-bold text-dark mb-1"><?php echo e($survey->title); ?></h2>
            <p class="text-muted small mb-0"><?php echo e($survey->description); ?></p>
        </div>

        <div class="admin-card">
            <div class="admin-card-header bg-light-subtle">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-person-circle text-primary fs-5"></i>
                    <div>
                        <div class="fw-bold small text-dark">Comunero(a) Informante: <?php echo e($user->name); ?></div>
                        <div class="text-muted" style="font-size: 0.76rem;">Vereda: <?php echo e($user->vereda ?? 'Zanjón de Garrapatero'); ?> &bull; Cédula: <?php echo e($user->document_number ?? 'Comunero Censado'); ?></div>
                    </div>
                </div>
            </div>

            <div class="admin-card-body p-4">
                <form action="<?php echo e(route('admin.surveys.submit', $survey)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="survey_id" value="<?php echo e($survey->id); ?>">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger rounded-4">
                            <ul class="mb-0 small">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(is_array($survey->questions)): ?>
                        <?php $__currentLoopData = $survey->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $qid = $q['id'] ?? 'q_' . $idx;
                                $label = $q['label'] ?? 'Pregunta ' . ($idx + 1);
                                $type = $q['type'] ?? 'text';
                            ?>

                            <div class="p-3 mb-4 rounded-4 border bg-white shadow-sm" style="border-left: 4px solid var(--admin-gold) !important;">
                                <label class="form-label fw-bold text-dark d-block mb-2">
                                    <span class="badge bg-primary me-2"><?php echo e($idx + 1); ?></span>
                                    <?php echo e($label); ?>

                                    <span class="text-danger">*</span>
                                </label>

                                <?php if($type === 'textarea'): ?>
                                    <textarea name="answers[<?php echo e($qid); ?>]" rows="3" class="form-control rounded-3" placeholder="Escriba su respuesta detallada..." required><?php echo e(old("answers.$qid")); ?></textarea>
                                <?php elseif($type === 'number'): ?>
                                    <input type="number" name="answers[<?php echo e($qid); ?>]" class="form-control rounded-3" placeholder="0" min="0" value="<?php echo e(old("answers.$qid")); ?>" required>
                                <?php elseif($type === 'radio'): ?>
                                    <div class="d-flex flex-column gap-2 mt-2">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="answers[<?php echo e($qid); ?>]" id="<?php echo e($qid); ?>_si" value="Sí" required <?php echo e(old("answers.$qid") == 'Sí' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($qid); ?>_si">Sí</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="answers[<?php echo e($qid); ?>]" id="<?php echo e($qid); ?>_no" value="No" <?php echo e(old("answers.$qid") == 'No' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($qid); ?>_no">No</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="answers[<?php echo e($qid); ?>]" id="<?php echo e($qid); ?>_parcial" value="Parcialmente / En proceso" <?php echo e(old("answers.$qid") == 'Parcialmente / En proceso' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($qid); ?>_parcial">Parcialmente / En proceso</label>
                                        </div>
                                    </div>
                                <?php elseif($type === 'select'): ?>
                                    <select name="answers[<?php echo e($qid); ?>]" class="form-select rounded-3" required>
                                        <option value="">Seleccione una opción...</option>
                                        <option value="Agricultura tradicional" <?php echo e(old("answers.$qid") == 'Agricultura tradicional' ? 'selected' : ''); ?>>Agricultura tradicional</option>
                                        <option value="Piscicultura / Pesca" <?php echo e(old("answers.$qid") == 'Piscicultura / Pesca' ? 'selected' : ''); ?>>Piscicultura / Pesca</option>
                                        <option value="Ganadería menor" <?php echo e(old("answers.$qid") == 'Ganadería menor' ? 'selected' : ''); ?>>Ganadería menor</option>
                                        <option value="Artesanías y transformación" <?php echo e(old("answers.$qid") == 'Artesanías y transformación' ? 'selected' : ''); ?>>Artesanías y transformación</option>
                                        <option value="Comercio y servicios" <?php echo e(old("answers.$qid") == 'Comercio y servicios' ? 'selected' : ''); ?>>Comercio y servicios</option>
                                        <option value="Otro" <?php echo e(old("answers.$qid") == 'Otro' ? 'selected' : ''); ?>>Otro</option>
                                    </select>
                                <?php else: ?>
                                    <input type="text" name="answers[<?php echo e($qid); ?>]" class="form-control rounded-3" placeholder="Su respuesta..." value="<?php echo e(old("answers.$qid")); ?>" required>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <div class="mb-4">
                        <label for="notes" class="form-label fw-bold small text-dark">
                            <i class="bi bi-chat-left-dots text-warning me-1"></i>
                            Observaciones adicionales o sugerencias territoriales (Opcional):
                        </label>
                        <textarea name="notes" id="notes" rows="2" class="form-control rounded-3" placeholder="¿Desea agregar algún comentario para la Junta de Gobierno del Consejo?"><?php echo e(old('notes')); ?></textarea>
                    </div>

                    <div class="d-flex align-items-center justify-content-between pt-3 border-top">
                        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-outline-secondary rounded-pill px-4">
                            Cancelar
                        </a>
                        <button type="submit" class="btn-admin-gold px-4 py-2">
                            <i class="bi bi-send-check-fill me-1"></i> Registrar y Enviar Respuestas
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/surveys/respond.blade.php ENDPATH**/ ?>