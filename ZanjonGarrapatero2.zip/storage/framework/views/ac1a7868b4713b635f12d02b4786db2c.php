<?php $__env->startSection('title', 'Respuestas de Censo — ' . $survey->title); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
    <div>
        <a href="<?php echo e(route('admin.surveys.index')); ?>" class="btn btn-sm btn-admin-outline mb-2">
            <i class="bi bi-arrow-left"></i> Volver a Encuestas
        </a>
        <h2 class="h3 fw-bold text-dark mb-1">Auditoría de Respuestas: <?php echo e($survey->title); ?></h2>
        <div class="d-flex align-items-center gap-2">
            <span class="badge bg-light text-primary border"><?php echo e($survey->category); ?></span>
            <span class="badge bg-light text-dark border"><?php echo e($survey->target_vereda ?? 'Todo el Territorio'); ?></span>
            <span class="badge bg-success"><?php echo e($responses->total()); ?> comuneros participantes</span>
        </div>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 class="admin-card-title">
            <i class="bi bi-person-check-fill text-warning"></i>
            Registros Censales Individuales (<?php echo e($responses->total()); ?>)
        </h3>
    </div>
    <div class="admin-card-body p-0">
        <?php if($responses->isEmpty()): ?>
            <div class="p-5 text-center text-muted">
                <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                Aún no se han recibido respuestas para esta encuesta comunitaria.
            </div>
        <?php else: ?>
            <div class="table-responsive px-3 py-2">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Comunero / Informante</th>
                            <th>Vereda</th>
                            <th>Respuestas Capturadas</th>
                            <th>Observaciones</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($resp->user->name ?? 'Usuario'); ?></div>
                                    <div class="small text-muted"><?php echo e($resp->user->email ?? ''); ?></div>
                                    <div class="small text-secondary">Doc: <?php echo e($resp->user->document_number ?? 'S/D'); ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?php echo e($resp->user->vereda ?? 'Territorio'); ?></span>
                                </td>
                                <td>
                                    <div class="d-flex flex-column gap-1 small">
                                        <?php if(is_array($resp->answers)): ?>
                                            <?php $__currentLoopData = $resp->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <span class="text-muted fw-semibold"><?php echo e($key); ?>:</span>
                                                    <span class="text-dark"><?php echo e(is_array($val) ? implode(', ', $val) : $val); ?></span>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <span class="text-muted">Sin datos</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="small text-secondary"><?php echo e($resp->notes ?? '—'); ?></span>
                                </td>
                                <td>
                                    <span class="small text-secondary"><?php echo e($resp->created_at->format('d/m/Y H:i')); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="p-3 border-top">
                <?php echo e($responses->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/surveys/responses.blade.php ENDPATH**/ ?>