<?php $__env->startSection('title', 'Registrar Multimedia (Foto o Video)'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-form-container">
    <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
        <div>
            <a href="<?php echo e(route('admin.media.index')); ?>" class="btn btn-sm btn-outline-secondary mb-2">
                <i class="bi bi-arrow-left me-1"></i> Volver a Multimedia
            </a>
            <h2 class="h3 fw-bold text-dark mb-1">Registrar Fotografía o Video Comunitario</h2>
            <p class="text-muted small mb-0">Alimenta las secciones de Galería fotográfica y Videos territoriales del portal oficial.</p>
        </div>
    </div>

    <form action="<?php echo e(route('admin.media.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Clasificación del Medio','icon' => 'bi-collection-play','kicker' => '01 · Tipo & Categoría']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Clasificación del Medio','icon' => 'bi-collection-play','kicker' => '01 · Tipo & Categoría']); ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'title','label' => 'Título del Contenido','icon' => 'bi-type','placeholder' => 'Ej. Cosecha Tradicional de Cacao en la Vereda El Zanjón','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Título del Contenido','icon' => 'bi-type','placeholder' => 'Ej. Cosecha Tradicional de Cacao en la Vereda El Zanjón','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-4">
                    <?php if (isset($component)) { $__componentOriginalcaa826401539fc57a784dadbb5b3020d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcaa826401539fc57a784dadbb5b3020d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.select','data' => ['name' => 'type','label' => 'Tipo de Medio','icon' => 'bi-camera-video','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'type','label' => 'Tipo de Medio','icon' => 'bi-camera-video','required' => true]); ?>
                        <option value="image" <?php echo e(old('type') == 'image' ? 'selected' : ''); ?>>Fotografía (Galería)</option>
                        <option value="video" <?php echo e(old('type') == 'video' ? 'selected' : ''); ?>>Video Territorial (YouTube/MP4)</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $attributes = $__attributesOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $component = $__componentOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__componentOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginalcaa826401539fc57a784dadbb5b3020d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcaa826401539fc57a784dadbb5b3020d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.select','data' => ['name' => 'category','label' => 'Categoría Temática','icon' => 'bi-folder','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'category','label' => 'Categoría Temática','icon' => 'bi-folder','required' => true]); ?>
                        <option value="Territorio" <?php echo e(old('category') == 'Territorio' ? 'selected' : ''); ?>>Territorio y Paisajes</option>
                        <option value="Cultura" <?php echo e(old('category') == 'Cultura' ? 'selected' : ''); ?>>Cultura, Danza y Música</option>
                        <option value="Comunidad" <?php echo e(old('category') == 'Comunidad' ? 'selected' : ''); ?>>Vida Comunitaria y Familias</option>
                        <option value="Asambleas" <?php echo e(old('category') == 'Asambleas' ? 'selected' : ''); ?>>Asambleas y Encuentros</option>
                        <option value="Producción" <?php echo e(old('category') == 'Producción' ? 'selected' : ''); ?>>Agricultura y Saberes</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $attributes = $__attributesOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $component = $__componentOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__componentOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'duration','label' => 'Duración (Videos)','icon' => 'bi-stopwatch','placeholder' => 'Ej. 4:15 min']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'duration','label' => 'Duración (Videos)','icon' => 'bi-stopwatch','placeholder' => 'Ej. 4:15 min']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Archivo o Enlace de Transmisión','icon' => 'bi-cloud-arrow-up','kicker' => '02 · Carga & Enlace']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Archivo o Enlace de Transmisión','icon' => 'bi-cloud-arrow-up','kicker' => '02 · Carga & Enlace']); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginalf579f53fd7bfeb562be03b4886ced604 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf579f53fd7bfeb562be03b4886ced604 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dropzone','data' => ['name' => 'image_file','label' => 'Subir Fotografía (WebP Automático)','accept' => 'image/*','badge' => 'Nitidez optimizada • Máx 10 MB']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image_file','label' => 'Subir Fotografía (WebP Automático)','accept' => 'image/*','badge' => 'Nitidez optimizada • Máx 10 MB']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $attributes = $__attributesOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $component = $__componentOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__componentOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginalf579f53fd7bfeb562be03b4886ced604 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf579f53fd7bfeb562be03b4886ced604 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dropzone','data' => ['name' => 'video_file','label' => 'Subir Video Directo (MP4 / WebM)','accept' => 'video/mp4,video/webm,video/ogg,video/quicktime','badge' => 'Límite estricto: 50 MB']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'video_file','label' => 'Subir Video Directo (MP4 / WebM)','accept' => 'video/mp4,video/webm,video/ogg,video/quicktime','badge' => 'Límite estricto: 50 MB']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $attributes = $__attributesOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $component = $__componentOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__componentOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
                </div>
                <div class="col-12">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'file_url','label' => 'O bien, enlace URL externo (YouTube embed o CDN)','icon' => 'bi-link-45deg','placeholder' => 'https://www.youtube.com/embed/... o https://ejemplo.com/recurso.mp4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file_url','label' => 'O bien, enlace URL externo (YouTube embed o CDN)','icon' => 'bi-link-45deg','placeholder' => 'https://www.youtube.com/embed/... o https://ejemplo.com/recurso.mp4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-7">
                    <?php if (isset($component)) { $__componentOriginalf579f53fd7bfeb562be03b4886ced604 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf579f53fd7bfeb562be03b4886ced604 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dropzone','data' => ['name' => 'thumbnail_file','label' => 'Portada / Miniatura (Para videos)','accept' => 'image/*','badge' => 'Carátula previa del reproductor • WebP auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'thumbnail_file','label' => 'Portada / Miniatura (Para videos)','accept' => 'image/*','badge' => 'Carátula previa del reproductor • WebP auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $attributes = $__attributesOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $component = $__componentOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__componentOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
                </div>
                <div class="col-md-5">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'thumbnail_url','label' => 'O enlace URL de miniatura','icon' => 'bi-link-45deg','placeholder' => 'https://ejemplo.com/miniaturas/portada.jpg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'thumbnail_url','label' => 'O enlace URL de miniatura','icon' => 'bi-link-45deg','placeholder' => 'https://ejemplo.com/miniaturas/portada.jpg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-12">
                    <?php if (isset($component)) { $__componentOriginal694712473b787cd740db4e46be9da3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal694712473b787cd740db4e46be9da3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.textarea','data' => ['name' => 'caption','label' => 'Pie de Foto / Reseña Descriptiva','placeholder' => 'Contexto de la toma, autor de la fotografía o testimonio comunitario...','rows' => '3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'caption','label' => 'Pie de Foto / Reseña Descriptiva','placeholder' => 'Contexto de la toma, autor de la fotografía o testimonio comunitario...','rows' => '3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal694712473b787cd740db4e46be9da3f9)): ?>
<?php $attributes = $__attributesOriginal694712473b787cd740db4e46be9da3f9; ?>
<?php unset($__attributesOriginal694712473b787cd740db4e46be9da3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal694712473b787cd740db4e46be9da3f9)): ?>
<?php $component = $__componentOriginal694712473b787cd740db4e46be9da3f9; ?>
<?php unset($__componentOriginal694712473b787cd740db4e46be9da3f9); ?>
<?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Publicación y Destacados','icon' => 'bi-eye','kicker' => '03 · Difusión']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Publicación y Destacados','icon' => 'bi-eye','kicker' => '03 · Difusión']); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.switch','data' => ['name' => 'is_visible','label' => 'Visible en el Portal Público','description' => 'Aparecerá en la galería o videoteca para los comuneros y visitantes.','checked' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'is_visible','label' => 'Visible en el Portal Público','description' => 'Aparecerá en la galería o videoteca para los comuneros y visitantes.','checked' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $attributes = $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $component = $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.switch','data' => ['name' => 'is_featured','label' => 'Destacar en Portada','description' => 'Presentar en la sección de destacados o carrusel inicial del sitio.','checked' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'is_featured','label' => 'Destacar en Portada','description' => 'Presentar en la sección de destacados o carrusel inicial del sitio.','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $attributes = $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $component = $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala727e02234b4d11a6ac0075a108bae60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala727e02234b4d11a6ac0075a108bae60 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.actions','data' => ['cancelUrl' => ''.e(route('admin.media.index')).'','submitText' => 'Guardar Multimedia','icon' => 'bi-cloud-check']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['cancelUrl' => ''.e(route('admin.media.index')).'','submitText' => 'Guardar Multimedia','icon' => 'bi-cloud-check']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala727e02234b4d11a6ac0075a108bae60)): ?>
<?php $attributes = $__attributesOriginala727e02234b4d11a6ac0075a108bae60; ?>
<?php unset($__attributesOriginala727e02234b4d11a6ac0075a108bae60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala727e02234b4d11a6ac0075a108bae60)): ?>
<?php $component = $__componentOriginala727e02234b4d11a6ac0075a108bae60; ?>
<?php unset($__componentOriginala727e02234b4d11a6ac0075a108bae60); ?>
<?php endif; ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/media/create.blade.php ENDPATH**/ ?>