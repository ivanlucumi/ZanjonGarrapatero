<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'label',
    'description' => null,
    'checked' => true,
    'value' => '1',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'label',
    'description' => null,
    'checked' => true,
    'value' => '1',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="admin-switch-card">
    <div>
        <p class="switch-label"><?php echo e($label); ?></p>
        <?php if($description): ?>
            <p class="switch-desc"><?php echo e($description); ?></p>
        <?php endif; ?>
    </div>
    <div class="form-check form-switch m-0">
        <input 
            class="form-check-input" 
            type="checkbox" 
            role="switch" 
            name="<?php echo e($name); ?>" 
            id="<?php echo e($name); ?>" 
            value="<?php echo e($value); ?>" 
            <?php echo e(old($name, $checked ? '1' : '0') == '1' ? 'checked' : ''); ?>

            style="width: 2.8rem; height: 1.5rem; cursor: pointer;"
        >
    </div>
</div>
<?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/components/admin/switch.blade.php ENDPATH**/ ?>