<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'label',
    'accept' => '*/*',
    'badge' => 'Máx 10 MB',
    'current' => null,
    'currentUrl' => null,
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'label',
    'accept' => '*/*',
    'badge' => 'Máx 10 MB',
    'current' => null,
    'currentUrl' => null,
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="mb-3">
    <label class="admin-label">
        <span>
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="required-dot" title="Campo obligatorio">*</span>
            <?php endif; ?>
        </span>
        <?php if($current): ?>
            <span class="admin-label-hint text-success">
                <i class="bi bi-check2-circle me-1"></i>Archivo actual cargado
            </span>
        <?php endif; ?>
    </label>

    <div class="admin-dropzone-box">
        <input 
            type="file" 
            name="<?php echo e($name); ?>" 
            id="<?php echo e($name); ?>" 
            class="admin-dropzone-input" 
            accept="<?php echo e($accept); ?>"
            <?php if($required): ?> required <?php endif; ?>
            <?php echo e($attributes->except(['class'])); ?>

        >
        <div class="dz-icon">
            <i class="bi bi-cloud-arrow-up"></i>
        </div>
        <div class="dz-title">
            <span>Haz clic para explorar</span> o arrastra el archivo aquí
        </div>
        <span class="dz-badge"><?php echo e($badge); ?></span>

        <?php if($currentUrl): ?>
            <div class="mt-2 small text-muted">
                Archivo actual: <a href="<?php echo e($currentUrl); ?>" target="_blank" class="fw-semibold text-primary text-decoration-underline" style="pointer-events: auto; position: relative; z-index: 20;">Ver recurso</a>
            </div>
        <?php endif; ?>

        <div class="admin-dropzone-preview">
            <i class="bi bi-check-circle-fill text-success"></i>
            <span class="dz-filename">Archivo seleccionado</span>
        </div>
    </div>

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger small mt-1 fw-semibold">
            <i class="bi bi-exclamation-circle me-1"></i><?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/components/admin/dropzone.blade.php ENDPATH**/ ?>