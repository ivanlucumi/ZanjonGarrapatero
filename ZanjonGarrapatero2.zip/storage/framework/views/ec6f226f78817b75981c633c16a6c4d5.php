<?php $__env->startSection('title', 'Diseño 2 (Menú Lateral) — Consejo Comunitario Zanjón de Garrapatero'); ?>
<?php $__env->startSection('meta_description', 'Diseño 2 con menú lateral izquierdo para la presentación del proyecto institucional y comunitario del Consejo Comunitario Zanjón de Garrapatero.'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.index.content', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/layouts/index/index2.blade.php ENDPATH**/ ?>