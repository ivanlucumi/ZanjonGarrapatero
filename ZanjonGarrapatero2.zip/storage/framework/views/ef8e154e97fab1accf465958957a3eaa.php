<?php $__env->startSection('title', 'Editar Diapositiva del Carrusel'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-form-container">
    <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
        <div>
            <a href="<?php echo e(route('admin.carousel.index')); ?>" class="btn btn-sm btn-outline-secondary mb-2">
                <i class="bi bi-arrow-left me-1"></i> Volver al Carrusel
            </a>
            <h2 class="h3 fw-bold text-dark mb-1">Editar: <?php echo e($slide->title); ?></h2>
            <p class="text-muted small mb-0">Toda modificación quedará registrada con fecha, usuario e IP en la bitácora de auditoría.</p>
        </div>
        <?php if($slide->trashed()): ?>
            <span class="badge bg-danger-subtle text-danger border border-danger px-3 py-2 rounded-pill">
                <i class="bi bi-archive-fill me-1"></i> En papelera / Histórico (Inactivo)
            </span>
        <?php endif; ?>
    </div>

    <form action="<?php echo e(route('admin.carousel.update', $slide->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Contenido y Textos Principales','icon' => 'bi-card-heading','kicker' => '01 · Portada & Titulares']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Contenido y Textos Principales','icon' => 'bi-card-heading','kicker' => '01 · Portada & Titulares']); ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'title','label' => 'Título Principal (H1/H2)','icon' => 'bi-type-h1','value' => $slide->title,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Título Principal (H1/H2)','icon' => 'bi-type-h1','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->title),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-4">
                    <?php if (isset($component)) { $__componentOriginalcaa826401539fc57a784dadbb5b3020d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcaa826401539fc57a784dadbb5b3020d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.select','data' => ['name' => 'type','label' => 'Tipo de Diapositiva','icon' => 'bi-film','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'type','label' => 'Tipo de Diapositiva','icon' => 'bi-film','required' => true]); ?>
                        <option value="image" <?php echo e(old('type', $slide->type) == 'image' ? 'selected' : ''); ?>>Foto / Imagen de Fondo</option>
                        <option value="video" <?php echo e(old('type', $slide->type) == 'video' ? 'selected' : ''); ?>>Video en Proyección</option>
                        <option value="none" <?php echo e(old('type', $slide->type) == 'none' ? 'selected' : ''); ?>>Editorial (Sin fondo)</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $attributes = $__attributesOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__attributesOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcaa826401539fc57a784dadbb5b3020d)): ?>
<?php $component = $__componentOriginalcaa826401539fc57a784dadbb5b3020d; ?>
<?php unset($__componentOriginalcaa826401539fc57a784dadbb5b3020d); ?>
<?php endif; ?>
                </div>
                <div class="col-md-8">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'badge_text','label' => 'Texto de la Píldora Superior','icon' => 'bi-tag','value' => $slide->badge_text]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'badge_text','label' => 'Texto de la Píldora Superior','icon' => 'bi-tag','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->badge_text)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-4">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'sort_order','type' => 'number','label' => 'Orden de Aparición','icon' => 'bi-sort-numeric-down','value' => $slide->sort_order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sort_order','type' => 'number','label' => 'Orden de Aparición','icon' => 'bi-sort-numeric-down','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->sort_order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-12">
                    <?php if (isset($component)) { $__componentOriginal694712473b787cd740db4e46be9da3f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal694712473b787cd740db4e46be9da3f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.textarea','data' => ['name' => 'subtitle','label' => 'Párrafo Descriptivo / Subtítulo','rows' => '3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'subtitle','label' => 'Párrafo Descriptivo / Subtítulo','rows' => '3']); ?><?php echo e(old('subtitle', $slide->subtitle)); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal694712473b787cd740db4e46be9da3f9)): ?>
<?php $attributes = $__attributesOriginal694712473b787cd740db4e46be9da3f9; ?>
<?php unset($__attributesOriginal694712473b787cd740db4e46be9da3f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal694712473b787cd740db4e46be9da3f9)): ?>
<?php $component = $__componentOriginal694712473b787cd740db4e46be9da3f9; ?>
<?php unset($__componentOriginal694712473b787cd740db4e46be9da3f9); ?>
<?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Recurso Multimedia y Proyección','icon' => 'bi-camera-reels','kicker' => '02 · Medios & Formatos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Recurso Multimedia y Proyección','icon' => 'bi-camera-reels','kicker' => '02 · Medios & Formatos']); ?>
            <div class="row g-3">
                <div class="col-md-7">
                    <?php if (isset($component)) { $__componentOriginalf579f53fd7bfeb562be03b4886ced604 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf579f53fd7bfeb562be03b4886ced604 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dropzone','data' => ['name' => 'media_file','label' => 'Reemplazar Archivo Multimedia (Opcional)','accept' => 'image/*,video/mp4,video/webm,video/ogg','badge' => 'Imágenes WebP auto-optimizadas • Videos máx 50 MB']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'media_file','label' => 'Reemplazar Archivo Multimedia (Opcional)','accept' => 'image/*,video/mp4,video/webm,video/ogg','badge' => 'Imágenes WebP auto-optimizadas • Videos máx 50 MB']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $attributes = $__attributesOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $component = $__componentOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__componentOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
                </div>
                <div class="col-md-5">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'media_url','label' => 'O enlace URL de recurso','icon' => 'bi-link-45deg','value' => $slide->media_url]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'media_url','label' => 'O enlace URL de recurso','icon' => 'bi-link-45deg','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->media_url)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                    <?php if($slide->media_url): ?>
                        <div class="small text-muted mt-1 text-truncate">
                            <span class="fw-semibold">Recurso actual:</span> <code><?php echo e($slide->media_url); ?></code>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'projection_title','label' => 'Título para Modal de Pantalla Completa','icon' => 'bi-arrows-fullscreen','value' => $slide->projection_title,'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'projection_title','label' => 'Título para Modal de Pantalla Completa','icon' => 'bi-arrows-fullscreen','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->projection_title),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-7">
                    <?php if (isset($component)) { $__componentOriginalf579f53fd7bfeb562be03b4886ced604 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf579f53fd7bfeb562be03b4886ced604 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dropzone','data' => ['name' => 'poster_file','label' => 'Reemplazar Miniatura / Poster (Para videos)','accept' => 'image/*','badge' => 'Foto previa antes de reproducir • WebP optimizado']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'poster_file','label' => 'Reemplazar Miniatura / Poster (Para videos)','accept' => 'image/*','badge' => 'Foto previa antes de reproducir • WebP optimizado']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $attributes = $__attributesOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__attributesOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf579f53fd7bfeb562be03b4886ced604)): ?>
<?php $component = $__componentOriginalf579f53fd7bfeb562be03b4886ced604; ?>
<?php unset($__componentOriginalf579f53fd7bfeb562be03b4886ced604); ?>
<?php endif; ?>
                </div>
                <div class="col-md-5">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'poster_url','label' => 'O enlace URL de miniatura','icon' => 'bi-link-45deg','value' => $slide->poster_url]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'poster_url','label' => 'O enlace URL de miniatura','icon' => 'bi-link-45deg','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->poster_url)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                    <?php if($slide->poster_url): ?>
                        <div class="small text-muted mt-1 text-truncate">
                            <span class="fw-semibold">Poster actual:</span> <code><?php echo e($slide->poster_url); ?></code>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal4573713f1b5a138d14943a70418d8095 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4573713f1b5a138d14943a70418d8095 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.form-card','data' => ['title' => 'Botones de Enlace y Publicación','icon' => 'bi-cursor','kicker' => '03 · Interacción & Estado']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.form-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Botones de Enlace y Publicación','icon' => 'bi-cursor','kicker' => '03 · Interacción & Estado']); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'primary_button_text','label' => 'Texto Botón Primario','icon' => 'bi-box-arrow-up-right','value' => $slide->primary_button_text]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'primary_button_text','label' => 'Texto Botón Primario','icon' => 'bi-box-arrow-up-right','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->primary_button_text)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'primary_button_url','label' => 'Ruta / Enlace Primario','icon' => 'bi-link','value' => $slide->primary_button_url]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'primary_button_url','label' => 'Ruta / Enlace Primario','icon' => 'bi-link','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->primary_button_url)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'secondary_button_text','label' => 'Texto Botón Secundario (Opcional)','icon' => 'bi-box-arrow-up-right','value' => $slide->secondary_button_text]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'secondary_button_text','label' => 'Texto Botón Secundario (Opcional)','icon' => 'bi-box-arrow-up-right','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->secondary_button_text)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if (isset($component)) { $__componentOriginal187e7f8ae725d0d7c586a97e85953c03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.input','data' => ['name' => 'secondary_button_url','label' => 'Ruta / Enlace Secundario (Opcional)','icon' => 'bi-link','value' => $slide->secondary_button_url]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'secondary_button_url','label' => 'Ruta / Enlace Secundario (Opcional)','icon' => 'bi-link','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->secondary_button_url)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $attributes = $__attributesOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__attributesOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03)): ?>
<?php $component = $__componentOriginal187e7f8ae725d0d7c586a97e85953c03; ?>
<?php unset($__componentOriginal187e7f8ae725d0d7c586a97e85953c03); ?>
<?php endif; ?>
                </div>
                <div class="col-12 mt-2">
                    <?php if (isset($component)) { $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.switch','data' => ['name' => 'is_visible','label' => 'Publicar Diapositiva Inmediatamente','description' => 'Visible al público en el carrusel de portada de la página de inicio.','checked' => $slide->is_visible]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'is_visible','label' => 'Publicar Diapositiva Inmediatamente','description' => 'Visible al público en el carrusel de portada de la página de inicio.','checked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($slide->is_visible)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $attributes = $__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__attributesOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb)): ?>
<?php $component = $__componentOriginal3ac63cebb29d2e595958e8cb368d65bb; ?>
<?php unset($__componentOriginal3ac63cebb29d2e595958e8cb368d65bb); ?>
<?php endif; ?>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $attributes = $__attributesOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__attributesOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4573713f1b5a138d14943a70418d8095)): ?>
<?php $component = $__componentOriginal4573713f1b5a138d14943a70418d8095; ?>
<?php unset($__componentOriginal4573713f1b5a138d14943a70418d8095); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginala727e02234b4d11a6ac0075a108bae60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala727e02234b4d11a6ac0075a108bae60 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.actions','data' => ['cancelUrl' => ''.e(route('admin.carousel.index')).'','submitText' => 'Guardar Cambios','icon' => 'bi-check-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['cancelUrl' => ''.e(route('admin.carousel.index')).'','submitText' => 'Guardar Cambios','icon' => 'bi-check-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala727e02234b4d11a6ac0075a108bae60)): ?>
<?php $attributes = $__attributesOriginala727e02234b4d11a6ac0075a108bae60; ?>
<?php unset($__attributesOriginala727e02234b4d11a6ac0075a108bae60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala727e02234b4d11a6ac0075a108bae60)): ?>
<?php $component = $__componentOriginala727e02234b4d11a6ac0075a108bae60; ?>
<?php unset($__componentOriginala727e02234b4d11a6ac0075a108bae60); ?>
<?php endif; ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ZanjonGarrapatero\resources\views/admin/carousel/edit.blade.php ENDPATH**/ ?>